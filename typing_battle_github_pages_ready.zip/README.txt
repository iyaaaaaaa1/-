タイピングバトル GitHub Pages 公開用ファイル

1. GitHubにログインして新しいPublicリポジトリを作成します。
2. このフォルダ内の index.html をリポジトリの一番上にアップロードし、Commit changesします。
3. リポジトリの Settings > Pages を開きます。
4. Build and deployment > Source を Deploy from a branch にします。
5. Branch を main、フォルダを /(root) にして Saveします。
6. 公開後、https://ユーザー名.github.io/リポジトリ名/ を開きます。

※ GitHub Pagesのサイトは公開URLから誰でもアクセスできます。APIキーや個人情報をHTMLに入れないでください。
